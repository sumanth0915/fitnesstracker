// TutorialsPage.js
import React, { useState } from 'react';

const TutorialsPage = () => {
  const [tutorials, setTutorials] = useState([
    {
      id: 1,
      title: 'Proper Squat Form',
      category: 'Legs',
      duration: '8 min',
      difficulty: 'Beginner',
      imageUrl: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      instructor: 'Alex Rivera',
      description: 'Learn proper squat technique to maximize results and prevent injury.'
    },
    {
      id: 2,
      title: 'Bench Press Mastery',
      category: 'Chest',
      duration: '10 min',
      difficulty: 'Intermediate',
      imageUrl: 'https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      instructor: 'Sarah Chen',
      description: 'Master bench press form for chest development and strength gains.'
    },
    {
      id: 3,
      title: 'HIIT Training Fundamentals',
      category: 'Cardio',
      duration: '12 min',
      difficulty: 'All Levels',
      imageUrl: 'https://images.unsplash.com/photo-1599058917765-a780eda07a3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      instructor: 'Mike Johnson',
      description: 'High-intensity interval training for effective calorie burning.'
    },
    {
      id: 4,
      title: 'Deadlift Fundamentals',
      category: 'Back',
      duration: '15 min',
      difficulty: 'Intermediate',
      imageUrl: 'https://images.unsplash.com/photo-1603287681836-b174ce5074c2?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      instructor: 'Emma Williams',
      description: 'Essential deadlift techniques for overall body strength.'
    },
    {
      id: 5,
      title: 'Mobility Flow Routine',
      category: 'Recovery',
      duration: '20 min',
      difficulty: 'Beginner',
      imageUrl: 'https://images.unsplash.com/photo-1601422539283-884b3c12d38c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      instructor: 'David Lee',
      description: 'Improve flexibility and prevent injuries with this mobility routine.'
    },
    {
      id: 6,
      title: 'Advanced Bicep Training',
      category: 'Arms',
      duration: '18 min',
      difficulty: 'Advanced',
      imageUrl: 'https://images.unsplash.com/photo-1583454155184-870a1f63aebc?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      instructor: 'Lisa Turner',
      description: 'Take your arm workouts to the next level with these advanced techniques.'
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  
  const categories = ['All', 'Legs', 'Chest', 'Back', 'Arms', 'Cardio', 'Recovery'];

  const filteredTutorials = tutorials.filter(tutorial => {
    const matchesSearch = tutorial.title.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || tutorial.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="bg-gray-50 min-h-screen overflow-y-scroll">
      <div className="relative h-64 bg-gradient-to-r from-blue-600 to-indigo-800 mb-8">
        <div className="absolute inset-0 bg-black opacity-30"></div>
        <div className="container mx-auto px-6 relative z-10 flex items-center h-full text-white">
          <div>
            <h1 className="text-4xl font-bold mb-2">Fitness Tutorials</h1>
            <p className="text-lg text-blue-100 max-w-2xl">
              Learn proper form and techniques from expert trainers to maximize your results and prevent injuries.
            </p>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 pb-12">
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="relative w-full md:w-64">
              <input
                type="text"
                placeholder="Search tutorials..."
                className="w-full p-3 pl-10 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <svg className="absolute left-3 top-3.5 h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            
            <div className="flex flex-wrap gap-2">
              {categories.map(category => (
                <button
                  key={category}
                  className={`px-4 py-2 rounded-full transition-all ${
                    selectedCategory === category 
                      ? 'bg-blue-600 text-white shadow-md' 
                      : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
                  }`}
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </button>
              ))}
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredTutorials.map(tutorial => (
            <div key={tutorial.id} className="bg-white rounded-xl shadow-md overflow-hidden transition-transform hover:scale-105 hover:shadow-lg">
              <div className="relative h-56">
                <img 
                  src={tutorial.imageUrl} 
                  alt={tutorial.title} 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black opacity-60"></div>
                <div className="absolute bottom-0 left-0 p-4 flex justify-between items-center w-full">
                  <span className="bg-blue-600 text-white text-xs font-medium px-2.5 py-1 rounded">
                    {tutorial.category}
                  </span>
                  <span className="bg-black bg-opacity-60 text-white text-xs font-medium px-2.5 py-1 rounded">
                    {tutorial.duration}
                  </span>
                </div>
                <button className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white bg-opacity-80 rounded-full p-3 hover:bg-opacity-100 transition-all">
                  <svg className="h-8 w-8 text-blue-600" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z" />
                  </svg>
                </button>
              </div>
              <div className="p-5">
                <div className="flex items-center mb-3">
                  <div className="bg-gray-200 rounded-full h-8 w-8 flex items-center justify-center mr-2">
                    {tutorial.instructor.charAt(0)}
                  </div>
                  <span className="text-sm text-gray-600">{tutorial.instructor}</span>
                  <span className="ml-auto text-xs font-medium text-white bg-blue-100 text-blue-800 rounded px-2 py-1">
                    {tutorial.difficulty}
                  </span>
                </div>
                <h2 className="text-xl font-bold mb-2 text-gray-800">{tutorial.title}</h2>
                <p className="text-gray-600 mb-4">{tutorial.description}</p>
                <button className="bg-blue-600 hover:bg-blue-700 text-white py-3 px-4 rounded-lg w-full flex items-center justify-center transition-all">
                  <svg className="h-5 w-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Watch Tutorial
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredTutorials.length === 0 && (
          <div className="text-center py-16">
            <svg className="h-16 w-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <h3 className="text-xl font-medium text-gray-700 mb-1">No tutorials found</h3>
            <p className="text-gray-500">Try adjusting your search or filter to find what you're looking for.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default TutorialsPage;
import React, { useState } from 'react';

const BlogsPage = () => {
  const [blogs, setBlogs] = useState([
    {
      id: 1,
      title: 'How to Build a Sustainable Workout Routine',
      author: 'Alex Johnson',
      authorImage: 'https://images.unsplash.com/photo-1568602471122-7832951cc4c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80',
      date: 'April 8, 2025',
      category: 'Fitness Tips',
      image: 'https://images.unsplash.com/photo-1595078475328-1ab05d0a6a0e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      readTime: '8 min read',
      excerpt: 'Creating a workout routine you can stick to is key for long-term fitness success. Here are practical strategies to build sustainable habits.',
      featured: false
    },
    {
      id: 2,
      title: 'Nutrition Basics for Muscle Growth',
      author: 'Sarah Williams',
      authorImage: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80',
      date: 'April 5, 2025',
      category: 'Nutrition',
      image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      readTime: '12 min read',
      excerpt: 'Learn the fundamentals of proper nutrition to support muscle growth and recovery after intense training sessions.',
      featured: false
    },
    {
      id: 3,
      title: 'The Science Behind HIIT Workouts',
      author: 'Michael Chen',
      authorImage: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80',
      date: 'April 1, 2025',
      category: 'Cardio',
      image: 'https://images.unsplash.com/photo-1434682881908-b43d0467b798?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      readTime: '10 min read',
      excerpt: 'High-intensity interval training has become incredibly popular, but what does the science say about its effectiveness?',
      featured: false
    },
    {
      id: 4,
      title: 'Rest and Recovery: Why It Matters',
      author: 'Emma Davis',
      authorImage: 'https://images.unsplash.com/photo-1499952127939-9bbf5af6c51c?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80',
      date: 'March 28, 2025',
      category: 'Recovery',
      image: 'https://images.unsplash.com/photo-1520359319979-f360d010d777?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80',
      readTime: '7 min read',
      excerpt: 'Recovery is just as important as your workouts. Discover why adequate rest is crucial for fitness progress.',
      featured: false
    },
    {
      id: 5,
      title: '5 Workout Myths Debunked by Science',
      author: 'Dr. James Wilson',
      authorImage: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80',
      date: 'April 10, 2025',
      category: 'Featured',
      image: 'https://images.unsplash.com/photo-1574680096145-d05b474e2155?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      readTime: '15 min read',
      excerpt: 'Separate fitness facts from fiction with evidence-based insights about common workout misconceptions that could be holding you back.',
      featured: true
    }
  ]);

  const [selectedCategory, setSelectedCategory] = useState('All');
  const categories = ['All', 'Fitness Tips', 'Nutrition', 'Cardio', 'Recovery'];
  
  const featuredBlog = blogs.find(blog => blog.featured);
  const regularBlogs = blogs.filter(blog => !blog.featured);
  
  const filteredBlogs = selectedCategory === 'All' 
    ? regularBlogs 
    : regularBlogs.filter(blog => blog.category === selectedCategory);

  return (
    <div className="bg-gray-50 min-h-screen overflow-y-scroll">
      {featuredBlog && (
        <div className="relative h-96">
          <img 
            src={featuredBlog.image} 
            alt={featuredBlog.title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>
          <div className="absolute bottom-0 left-0 right-0 p-8">
            <div className="container mx-auto">
              <span className="bg-blue-600 text-white text-sm font-medium px-3 py-1 rounded mb-3 inline-block">
                {featuredBlog.category}
              </span>
              <h2 className="text-4xl font-bold text-white mb-3">{featuredBlog.title}</h2>
              <p className="text-white text-opacity-90 mb-4 max-w-2xl">{featuredBlog.excerpt}</p>
              <div className="flex items-center">
                <img 
                  src={featuredBlog.authorImage} 
                  alt={featuredBlog.author} 
                  className="w-10 h-10 rounded-full mr-3 object-cover"
                />
                <div>
                  <p className="text-white font-medium">{featuredBlog.author}</p>
                  <p className="text-white text-opacity-70 text-sm">{featuredBlog.date} · {featuredBlog.readTime}</p>
                </div>
                <button className="ml-auto bg-blue-600 hover:bg-blue-700 text-white py-2 px-6 rounded-lg transition-all">
                  Read Article
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      
      <div className="container mx-auto px-6 py-12">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-4 md:mb-0">Latest Articles</h1>
          
          <div className="flex flex-wrap gap-2">
            {categories.map(category => (
              <button
                key={category}
                className={`px-4 py-2 rounded-full transition-all ${
                  selectedCategory === category 
                    ? 'bg-blue-600 text-white shadow-md' 
                    : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
                }`}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredBlogs.map(blog => (
            <div key={blog.id} className="bg-white rounded-xl shadow-md overflow-hidden transition-transform hover:scale-105 hover:shadow-lg">
              <div className="h-48 overflow-hidden">
                <img 
                  src={blog.image} 
                  alt={blog.title} 
                  className="w-full h-full object-cover hover:scale-110 transition-transform duration-700"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center mb-3">
                  <span className="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">
                    {blog.category}
                  </span>
                  <span className="text-gray-500 text-sm ml-auto">{blog.readTime}</span>
                </div>
                <h2 className="text-xl font-bold mb-3 text-gray-800 line-clamp-2 hover:text-blue-600 transition-colors">
                  {blog.title}
                </h2>
                <p className="text-gray-600 mb-5 line-clamp-3">{blog.excerpt}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <img 
                      src={blog.authorImage} 
                      alt={blog.author} 
                      className="w-8 h-8 rounded-full mr-2 object-cover" 
                    />
                    <div>
                      <p className="text-sm font-medium text-gray-800">{blog.author}</p>
                      <p className="text-xs text-gray-500">{blog.date}</p>
                    </div>
                  </div>
                  <button className="text-blue-600 hover:text-blue-800 transition-colors">
                    Read more
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 flex justify-center">
          <nav className="flex items-center">
            <button className="mx-1 px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-100 transition-colors">
              Previous
            </button>
            <button className="mx-1 px-4 py-2 rounded-lg bg-blue-600 text-white">1</button>
            <button className="mx-1 px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-100 transition-colors">
              2
            </button>
            <button className="mx-1 px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-100 transition-colors">
              3
            </button>
            <button className="mx-1 px-4 py-2 rounded-lg border border-gray-300 hover:bg-gray-100 transition-colors">
              Next
            </button>
          </nav>
        </div>
      </div>
    </div>
  );
};

export default BlogsPage;

